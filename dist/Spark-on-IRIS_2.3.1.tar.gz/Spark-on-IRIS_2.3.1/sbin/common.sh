#!/usr/bin/env bash

if [ -L ${BASH_SOURCE-$0} ]; then
    FWDIR=$(dirname $(readlink "${BASH_SOURCE-$0}"))
else
    FWDIR=$(dirname "${BASH_SOURCE-$0}")
fi

if [[ -z "${PROJECT_HOME}" ]]; then
    export PROJECT_HOME="$(cd "${FWDIR}/.."; pwd)"
fi

if [[ -z "${CONF_DIR}" ]]; then
    export CONF_DIR="${PROJECT_HOME}/etc"
fi

if [[ -z "${LOG_DIR}" ]]; then
    export LOG_DIR="${PROJECT_HOME}/logs"
fi

if [[ -z "$PID_DIR" ]]; then
    export PID_DIR="${PROJECT_HOME}/pids"
fi

if [[ -n "${PYTHON_INTERPRETER}" ]]; then
    export PYTHON_INTERPRETER=$(which python2.7)
fi

if [[ -z "$DEBUG" ]]; then
    export DEBUG=0
fi