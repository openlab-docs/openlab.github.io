#!/usr/bin/env bash

#set -x

USAGE="-e USAGE: $0\t {start|start-foreground|stop|restart|reload|status}\n\t-h, --help print argument options"

if [ -L ${BASH_SOURCE-$0} ]; then
    BIN=$(dirname $(readlink "${BASH_SOURCE-$0}"))
else
    BIN=$(dirname ${BASH_SOURCE-$0})
fi
BIN=$(cd "${BIN}">/dev/null; pwd)

. "${BIN}/common.sh"
. "${BIN}/functions.sh"

HOSTNAME=$(hostname)
DAEMON_NAME="iris-rpc-server"

LOGFILE="${LOG_DIR}/${DAEMON_NAME}-${HOSTNAME}.log"
PIDFILE="${PID_DIR}/${DAEMON_NAME}-${HOSTNAME}.pid"

EXECUTABLE=$(cd ${PROJECT_HOME}/bin; pwd)/iris-rpc-server

if [[ "${NICENESS}" = "" ]]; then
    # default: inherit parent scheduling priority
    export NICENESS=0
fi

function check_and_install_dependencies() {
    python -c "import thrift" 2> /dev/null
    is_installed=$?
    if [ ${is_installed} -ne 0 ]; then
        echo "install thrift python package"
        ${PROJECT_HOME}/lib/python/thrift-0.9.3/setup.py install
    fi
}

function set_environments() {
   export PYTHONPATH=${PROJECT_HOME}/iris/src/main/python:${PROJECT_HOME}/lib/python/M6.zip:${PYTHONPATH}
}

function initialize_default_directories() {
    if [[ ! -d "${LOG_DIR}" ]]; then
        echo "log dir doesn't exists, create ${LOG_DIR}"
        $(mkdir -p "${LOG_DIR}")
    fi

    if [[ ! -d "${PID_DIR}" ]]; then
        echo "pid dir doesn't exists, create ${PID_DIR}"
        $(mkdir -p "${PID_DIR}")
    fi
}

function print_log_for_ci() {
    if [[ "${CI}" == "true" ]]; then
        tail -1000 "${LOGFILE}" | sed 's/^/  /'
    fi
}

function wait_for_die() {
    local pid
    local count
    pid=$1
    timeout=$2
    count=0
    timeoutTime=$(date "+%s")
    let "timeoutTime+=$timeout"
    currentTime=$(date "+%s")
    forceKill=1

    while [[ $currentTime -lt $timeoutTime ]]; do
        $(kill ${pid} > /dev/null 2> /dev/null)
        if kill -9 ${pid} > /dev/null 2>&1; then
            sleep 3
        else
            forceKill=0
            break
        fi
        currentTime=$(date "+%s")
    done

    if [[ forceKill -ne 0 ]]; then
        $(kill -9 ${pid} > /dev/null 2> /dev/null)
    fi
}

function check_if_process_is_alive() {
    local pid
    pid=$(cat ${PIDFILE})
    if ! kill -0 ${pid} >/dev/null 2>&1; then
        action_msg "${DAEMON_NAME} process died" "${SET_ERROR}"
        print_log_for_ci
        return 1
    fi
}

function start() {
    local pid

    if [[ -f "${PIDFILE}" ]]; then
        pid=$(cat ${PIDFILE})
        if kill -0 ${pid} >/dev/null 2>&1; then
            echo "${DAEMON_NAME} is already running"
            return 0;
        fi
    fi

    check_and_install_dependencies
    initialize_default_directories

    shift
    args=$@

    set_environments
    nohup nice -n $NICENESS $EXECUTABLE $args >> "${LOGFILE}" 2>&1 < /dev/null &
    pid=$!
    if [[ -z "${pid}" ]]; then
        action_msg "${DAEMON_NAME} start" "${SET_ERROR}"
        return 1;
    else
        action_msg "${DAEMON_NAME} start" "${SET_OK}"
        echo ${pid} > ${PIDFILE}
    fi

    sleep 2
    check_if_process_is_alive
}

function start-foreground(){
    shift
    args=$@

    set_environments
    $EXECUTABLE $args
}

function stop() {
  local pid

    # entmod-manage-server daemon kill
    if [[ ! -f "${PIDFILE}" ]]; then
        echo "${DAEMON_NAME} is not running"
    else
        pid=$(cat ${PIDFILE})
        if [[ -z "${PIDFILE}" ]]; then
            echo "${DAEMON_NAME} is not running"
        else
            wait_for_die $pid 40
            $(rm -f ${PIDFILE})
            action_msg "${DAEMON_NAME} stop" "${SET_OK}"
        fi
    fi

    for f in ${PID_DIR}/*.pid; do
        if [[ ! -f ${f} ]]; then
            continue;
        fi

        pid=$(cat ${f})
        wait_for_die $pid 20
        $(rm -f ${f})
    done

}

function find_process() {
    local pid

    if [[ -f "${PIDFILE}" ]]; then
        pid=$(cat ${PIDFILE})
        if ! kill -0 ${pid} > /dev/null 2>&1; then
            action_msg "${DAEMON_NAME} running but process is dead" "${SET_ERROR}"
            return 1
        else
            action_msg "${DAEMON_NAME} is running (${pid})" "${SET_OK}"
        fi
    else
        action_msg "${DAEMON_NAME} is not running" "${SET_ERROR}"
        return 1
    fi
}

function print_help() {
    ${EXECUTABLE} -h
}

case "${1}" in
    start)
        start $@
        ;;
    start-foreground)
        start-foreground $@
        ;;
    stop)
        stop
        ;;
    reload)
        stop
        start
        ;;
    restart)
        stop
        start
        ;;
    status)
        find_process
        ;;
    -h | --help)
        print_help
        ;;
    *)
        echo ${USAGE}
esac
