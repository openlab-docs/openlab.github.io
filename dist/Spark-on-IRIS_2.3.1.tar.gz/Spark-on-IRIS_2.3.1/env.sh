#!/bin/bash

BIN_DIR=`cd \`dirname $0\`; pwd`

export PYTHONPATH=${BIN_DIR}/src/main/python:${BIN_DIR}/lib/python/M6.zip:${BIN_DIR}/lib/python/irisspark.zip:$PYTHONPATH:${BIN_DIR}/lib/python/m6rpc.zip
