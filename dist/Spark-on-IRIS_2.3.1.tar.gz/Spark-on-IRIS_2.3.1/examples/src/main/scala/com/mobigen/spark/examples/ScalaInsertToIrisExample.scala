package com.mobigen.spark.examples

import com.mobigen.spark.iris.IrisContext
import org.apache.spark.sql.Row
import org.apache.spark.{SparkConf, SparkContext}

object ScalaInsertToIrisExample {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local[*]")
    conf.setAppName("InsertToIris")
    conf.set("spark.ui.port", "4444")

    conf.set("spark.sql.iris.host", "192.168.100.175")
    conf.set("spark.sql.iris.user", "root")
    conf.set("spark.sql.iris.passwd", "m6administrator")

    val sc = new SparkContext(conf)
    val irisContext = new IrisContext(sc)

    val source = getClass.getResource("/stocks-20080100000000.json")
    val stocksDF = irisContext.read.format("json").option("path", source.getPath).load()

    val createTableInfo = Map[String, String](
      "datascope" -> "LOCAL",
      "ramexpire" -> "43200",
      "diskexpire" -> "43200",
      "partitionkey" -> "exchange",
      "partitiondate" -> "date",
      "partitionrange" -> "1440"
    )

    val partitioner = (row: Row) => {
      val date = row.getString(2).split("-")
      val exchange = row.getString(3)

      (s"${date(0)}${date(1)}${date(2)}000000", exchange)
    }

    irisContext.saveAsIrisWithPartitioner(stocksDF, "STOCKS", partitioner, createInfo = createTableInfo)

    val insertedDF = irisContext.iris("STOCKS", hint = "LOCATION ( PARTITION = 20080102000000 )")
    insertedDF.show()

    irisContext.foreachBackend("SELECT * FROM STOCKS WHERE DATE = '2008-01-02'").show()
  }
}
