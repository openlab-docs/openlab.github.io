package com.mobigen.spark.examples

import com.mobigen.iris.jdbc.IRISResultSet
import com.mobigen.spark.iris.IrisContext
import org.apache.spark.{SparkConf, SparkContext}

object ScalaIrisContextExample {
  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf()
    conf.setMaster("local[*]")
    conf.setAppName("InsertToIris")
    conf.set("spark.ui.port", "4444")

    conf.set("spark.sql.iris.host", "192.168.100.175")
    conf.set("spark.sql.iris.user", "root")
    conf.set("spark.sql.iris.passwd", "m6administrator")

    val sc: SparkContext = new SparkContext(conf)

    val irisContext: IrisContext = new IrisContext(sc) // extends SQLContext

    // irisContext.iris("SYS_DISK_INFO")
    //        equals
    // sqlContext.read.format("iris").option("table", "SYS_DISK_INFO").load()
//    val sysDiskInfoDF = irisContext.iris("SYS_DISK_INFO")
//
//    sysDiskInfoDF.registerTempTable("SYS_DISK_INFO")
//    val sparkQuery =
//      """
//        SELECT
//          NODE_ID,
//          sum(P_SIZE_T),
//          avg(P_SIZE_T)
//        FROM
//          SYS_DISK_INFO
//        GROUP BY NODE_ID"""
//
//    irisContext.sql(sparkQuery).show()

    val irisQuery =
      """SELECT NODE_ID,
          P_SIZE_T + 1
        FROM
          SYS_DISK_INFO
        GROUP BY NODE_ID
      """

//    irisContext.irisql("SELECT NODE_ID, P_SIZE_T + 1 FROM SYS_DISK_INFO GROUP BY NODE_ID").show()
//    irisContext.irisql("SELECT * FROM SYS_DISK_INFO").show()
    irisContext.irisql(irisQuery).show()
  }
}