package com.mobigen.spark.examples

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkContext, SparkConf}

object ScalaCreateIrisDataFrameExample {
  def main(args: Array[String]) {
    val conf = new SparkConf()
    conf.setMaster("local[*]")
    conf.set("spark.ui.port", "4444")
    conf.setAppName("CreateIrisDataFrameExample")

    val sc = new SparkContext(conf)
    val sqlContext = new SQLContext(sc)


    val irisDF = sqlContext.read.format("iris")
        .option("table", "SYS_DISK_INFO")
        .option("host", "192.168.100.175")
        .option("user", "root")
        .option("passwd", "m6administrator")
        .option("port", "5050")
        .option("dsdPort", "5110")
        .load()

    irisDF.printSchema()
    irisDF.show()
    irisDF.describe().show()
  }
}




