package com.mobigen.spark.examples

import com.mobigen.spark.iris.IrisContext
import org.apache.spark.{SparkConf, SparkContext}

object ScalaJoinWithOthersExample {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local[*]")
    conf.setAppName("InsertToIris")
    conf.set("spark.ui.port", "4444")

//    conf.set("spark.sql.iris.host", "192.168.100.175")
    conf.set("spark.sql.iris.host", "192.168.100.153")
    conf.set("spark.sql.iris.user", "root")
    conf.set("spark.sql.iris.passwd", "m6administrator")

    val sc = new SparkContext(conf)
    val irisContext = new IrisContext(sc)

    val source = getClass.getResource("/stocks-20080200000000.db")
    val jdbcDF = irisContext.read.format("jdbc")
      .option("url", s"jdbc:sqlite:${source.getPath}")
      .option("dbtable", "stocks")
      .load()

    jdbcDF.registerTempTable("feb")

    val irisDF = irisContext.iris("STOCKS")
    irisDF.show()
    irisDF.registerTempTable("jan")

    val sql =
      """
        SELECT
          jan.STOCK_SYMBOL,
          jan.DATE,
          sum(jan.ADJ_CLOSE) - sum(feb.ADJ_CLOSE) as diff_adj_close
        FROM
          jan JOIN feb ON
            jan.STOCK_SYMBOL = feb.STOCK_SYMBOL
        WHERE
          jan.STOCK_SYMBOL = 'AAPL'
        GROUP BY
          jan.STOCK_SYMBOL,
          jan.DATE
        ORDER BY
          jan.DATE
      """

    val resultDF = irisContext.sql(sql)
    resultDF.show()
  }
}
