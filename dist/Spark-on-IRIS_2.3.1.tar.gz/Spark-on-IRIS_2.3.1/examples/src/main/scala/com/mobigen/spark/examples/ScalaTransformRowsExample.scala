package com.mobigen.spark.examples

import com.mobigen.spark.iris.IrisContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row
import org.apache.spark.{SparkConf, SparkContext}

object ScalaTransformRowsExample {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setMaster("local[*]")
    conf.setAppName("InsertToIris")
    conf.set("spark.ui.port", "4444")

    //    conf.set("spark.sql.iris.host", "192.168.100.175")
    conf.set("spark.sql.iris.host", "192.168.100.153")
    conf.set("spark.sql.iris.user", "root")
    conf.set("spark.sql.iris.passwd", "m6administrator")

    val sc = new SparkContext(conf)
    val irisContext = new IrisContext(sc)

    val df = irisContext.iris("STOCKS")
    df.show()

    irisContext.udf.register("convert_to_date", (original: String) => {
      val date = original.split("-")
      s"${date(0)}${date(1)}${date(2)}000000"
    })

    df.registerTempTable("STOCKS")
    irisContext.sql("SELECT convert_to_date(DATE) as converted_dateformat FROM STOCKS").show()

    val rdd: RDD[Row] = df.rdd
    val groupedRdd = rdd.groupBy((row: Row) => {
      val stockSymbol: String = row.getString(7) // ex:) AACC
      val key: String = stockSymbol.substring(0, 1)

      key
    })

    import irisContext.implicits._
    val fieldNames: Array[String] = df.schema.fieldNames
    groupedRdd.toDF(
      fieldNames(0), fieldNames(1), fieldNames(2), fieldNames(3), fieldNames(4),
      fieldNames(5), fieldNames(6), fieldNames(7)
    ).show()
  }
}
