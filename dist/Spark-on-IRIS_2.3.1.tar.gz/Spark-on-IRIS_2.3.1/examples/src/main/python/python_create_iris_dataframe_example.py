from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext

conf = SparkConf()
conf.setMaster("local[*]")
conf.set("spark.ui.port", 4444)
conf.setAppName("CreateIrisDataFrameExample")

sc = SparkContext(conf)
sqlContext = SQLContext(sc)

irisDF = sqlContext.read.format("iris")\
    .option("table", "SYS_DISK_INFO")\
    .option("host", "192.168.100.153")\
    .option("user", "root")\
    .option("passwd", "m6administrator")\
    .option("port", "5050")\
    .option("dsdPort", "5110")\
    .load()

irisDF.show()


