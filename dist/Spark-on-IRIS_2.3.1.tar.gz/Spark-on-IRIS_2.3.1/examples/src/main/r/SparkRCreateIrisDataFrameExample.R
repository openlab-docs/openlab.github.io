
if (nchar(Sys.getenv("SPARK_HOME")) < 1) {
    Sys.setenv(SPARK_HOME = "/home/iris/tools/spark")
}

library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"), "R", "lib")))

sc <- sparkR.init(master = "local[*]", sparkEnvir = list(spark.ui.port="4444"))
sqlContext <- sparkRSQL.init(sc)

df <- read.df(sqlContext,
    source="iris",
    table="SYS_DISK_INFO",
    host="192.168.100.153",
    user="root",
    password="m6administrator",
    port="5050",
    dsdPort="5110")

registerTempTable(df, "SYS_DISK_INFO")

resultDF <- sql(sqlContext, "SELECT * FROM SYS_DISK_INFO WHERE NODE_ID = 1")
showDF(resultDF)