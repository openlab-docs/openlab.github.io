package com.mobigen.spark.examples;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;

public class JavaCreateIrisDataFrameExample {
    public static void main(String[] args) {
//        SparkConf conf = new SparkConf();
//        conf.setMaster("local[*]");
//        conf.set("spark.ui.port", "4444");  // optional
//        conf.setAppName("CreateIrisDataFrameExample");
//        JavaSparkContext sc = new JavaSparkContext(conf);
//
//        SQLContext sqlContext = new SQLContext(sc);
//
//        DataFrame irisDF = sqlContext.read().format("iris")
//                .option("table", "SYS_DISK_INFO")
//                .option("host", "192.168.100.153")
//                .option("user", "root")
//                .option("passwd", "m6administrator")
//                .option("port", "5050")
//                .option("dsdPort", "5110")
//                .load();
//
//        irisDF.show();
    }
}
