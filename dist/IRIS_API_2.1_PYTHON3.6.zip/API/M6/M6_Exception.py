
class LoginFailException(Exception) : pass
class ConnectionFailException(Exception) : pass
class LoadTypeException(Exception) : pass

