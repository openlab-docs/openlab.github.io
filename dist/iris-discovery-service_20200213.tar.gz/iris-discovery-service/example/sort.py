# coding: utf-8
from ply import yacc, lex

from angora.cmds.base import BaseCommand
from angora.exceptions import AngoraException


class SortCommand(BaseCommand):
    # TODO: Move those lexer and parser into `BaseCommand` to generalize them.
    # Currently, we are relying on the old parser. After replacing them all,
    # we should change `BaseCommand` and move these into `BaseCommand`.
    class SortLexer(object):
        tokens = ['PLUS', 'MINUS', 'NUMBER', 'TOKEN', 'COMMA']

        t_PLUS = r'\+'
        t_MINUS = r'-'
        t_COMMA = r','
        t_TOKEN = r'[^ |^,|^\+|^-]+'

        def t_NUMBER(self, t):
            r'\d+'
            t.value = int(t.value)
            return t

        # Define a rule so we can track line numbers
        def t_newline(self, t):
            r'\n+'
            t.lexer.lineno += len(t.value)

        t_ignore = ' \t'

        def t_error(self, t):
            raise SyntaxError("Syntax error near '%s'" % t.value)

        def build(self, **kwargs):
            self.lexer = lex.lex(module=self, **kwargs)
            return self.lexer

    class SortParser(object):
        tokens = ['PLUS', 'MINUS', 'NUMBER', 'TOKEN', 'COMMA']

        def p_fields(self, p):
            """
            fields : sort_expr
                   | NUMBER sort_expr
            """
            if len(p) == 2:
                p[0] = [None, p[1]]
            else:
                p[0] = [p[1], p[2]]

        def p_sort_expr(self, p):
            """
            sort_expr : TOKEN
                        | PLUS TOKEN
                        | MINUS TOKEN
                        | sort_expr COMMA sort_expr
            """
            if len(p) == 2:
                p[0] = [("+", p[1])]
            elif len(p) == 3:
                p[0] = [(p[1], p[2])]
            else:
                p[0] = p[1] + p[3]

        def p_error(self, p):
            if p is None:
                raise AngoraException("At least a field should be specified.")
            else:
                raise SyntaxError("Syntax error near '%s'" % p.value)

        def build(self, **kwargs):
            self.parser = yacc.yacc(module=self, **kwargs)
            return self.parser

    def __init__(self):
        super(SortCommand, self).__init__()
        self.lexer = SortCommand.SortLexer().build()
        self.new_parser = SortCommand.SortParser().build(write_tables=False, debug=False)

    def parse(self, raw_args, options=None):
        try:
            num, order_field_list = self.new_parser.parse(raw_args, lexer=self.lexer)
        except SyntaxError as e:
            e.args = ("%s [sort %s]" % (e.args, raw_args),)
            raise e

        ascending_list = []
        field_list = []
        for order, field in order_field_list:
            if order == "+":
                ascending = True
            else:
                ascending = False
            ascending_list.append(ascending)
            field_list.append(field)
        return num, (ascending_list, field_list)

    def execute(self, sqlCtx, df=None, parsed_args=None, partition=None, options=None):
        num, (ascending, field) = parsed_args
        sorted_df = df.sort(field, ascending=ascending)
        if num is not None:
            return sorted_df.limit(num)
        else:
            return sorted_df
