import unittest
from pyspark import SparkContext, SQLContext, SparkConf
from sort import SortCommand
from pyspark.sql import Row


class SortTests(unittest.TestCase):
    sqlCtx = None

    @classmethod
    def setUpClass(cls):
        """Do seting up class for test."""

        conf = SparkConf()\
            .setMaster('local[2]')\
            .setAppName("TestApp")\
            .set('spark.port.maxRetries', 30)

        SortTests.sc = SparkContext(conf=conf) #spark://{ip}:9090
        SortTests.sqlCtx = SQLContext(SortTests.sc)
        SortTests.version = str(SortTests.sqlCtx._sc.version)

    def setUp(self):
        data = [
            ['20181029192000', 'mac', 43],
            ['20181029192010', 'mac', 45],
            ['20181029192020', 'mac', 54],
            ['20181029192030', 'mac', 25],
            ['20181029192040', 'mac', 10],
            ['20181029192050', 'mac', 75],
            ['20181029192100', 'mac', 50],
            ['20181029192110', 'mac', 65],
            ['20181029192120', 'mac', 80],
            ['20181029192130', 'mac', 65],
            ['20181029192140', 'mac', 61],
            ['20181029192150', 'mac', 64],
            ['20181029192200', 'mac', 66],
            ['20181029192210', 'mac', 75],
            ['20181029192220', 'mac', 88],
            ['20181029192230', 'mac', 29],
            ['20181029192240', 'mac', 52],
            ['20181029192250', 'mac', 75]
        ]

        self.test_df = SortTests.sqlCtx.createDataFrame(data,['time','host','value'])
        self.test_df = SortTests.sqlCtx.read.format('csv') \
                                                .option("header", "true") \
                                                .option("inferschema", "true") \
                                                .load("data.csv")
        
    def command_excute(self, cond):
        command = SortCommand()
        parsed_args = command.parse(cond)
        df = command.execute(SortTests.sqlCtx, self.test_df, parsed_args)
        return df.collect()

    def to_list(self, data):
        result = []
        for row in data:
            r = []
            r.append(row.time)
            r.append(row.host)
            r.append(row.value)
            result.append(r)

        return result

    def test_case1(self):
        result = self.command_excute("5 value")

        result = self.to_list(result)
        answer = [
            [20181029192040, 'mac', 10],
            [20181029192030, 'mac', 25],
            [20181029192230, 'mac', 29],
            [20181029192000, 'mac', 43],
            [20181029192010, 'mac', 45]
        ]

        self.assertEqual(result, answer)

    def test_case2(self):
        result = self.command_excute("5 -value")

        result = self.to_list(result)
        answer = [
            [20181029192220, 'mac', 88],
            [20181029192120, 'mac', 80],
            [20181029192050, 'mac', 75],
            [20181029192210, 'mac', 75],
            [20181029192250, 'mac', 75]
        ]

        self.assertEqual(result, answer)

    def test_case3(self):
        result = self.command_excute("5 -value, time")

        result = self.to_list(result)
        answer = [
            [20181029192220, 'mac', 88],
            [20181029192120, 'mac', 80],
            [20181029192050, 'mac', 75],
            [20181029192210, 'mac', 75],
            [20181029192250, 'mac', 75]
        ]

        self.assertEqual(result, answer)

if __name__ == "__main__":
    unittest.main()
