from angora.cmds.base import SimpleCommand
from angora.exceptions import AngoraException

import pyspark

import numpy
import ply
import pandas
import statsmodels

print("pyspark     {}".format(pyspark.__version__))
print("ply         {}".format(ply.__version__))
print("numpy       {}".format(numpy.__version__))
print("pandas      {}".format(pandas.__version__))
print("statsmodels {}".format(statsmodels.__version__))
