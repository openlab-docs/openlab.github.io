#!/bin/bash
export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_201.jdk/Contents/Home

# cd $(dirname "$0")
export ANGORA_SDK_HOME=`pwd`

if [[ -z ${SPARK_HOME} ]]; then
    export SPARK_HOME=${ANGORA_SDK_HOME}/thridpart/spark-2.4.4-bin-hadoop2.7
fi

if [[ ! -d ${SPARK_HOME} ]]; then
    echo "no search spark home directory, ${SPARK_HOME}"
    return
fi

if [[ ! -d ${JAVA_HOME} ]]; then
    echo "no search java home directory, ${JAVA_HOME}"
    return
fi

export PYTHONPATH=\
`ls ${ANGORA_SDK_HOME}/lib/ANGORA-CORE*.zip`:\
`ls ${SPARK_HOME}/python/lib/py4j-*-src.zip`:\
${SPARK_HOME}/python:\
${SPARK_HOME}/python/lib/pyspark.zip

echo "ANGORA_SDK_HOME=${ANGORA_SDK_HOME}"
echo "SPARK_HOME=${SPARK_HOME}"
echo "JAVA_HOME=${JAVA_HOME}"
